package com.mcit.scala.ClassEntities

case class TripRoute(trips: Trips, routes: Routes)

