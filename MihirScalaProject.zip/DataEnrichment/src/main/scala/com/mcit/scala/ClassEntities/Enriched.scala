package com.mcit.scala.ClassEntities

case class Enriched(tripRoute: TripRoute, calendar: Calendar)

