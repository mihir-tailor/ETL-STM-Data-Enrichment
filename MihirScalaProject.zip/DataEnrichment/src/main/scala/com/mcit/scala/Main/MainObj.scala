package com.mcit.scala.Main

import com.mcit.scala.ClassEntities._
import com.mcit.scala.RWdata.{DataReader, DataWriter}

object MainObj extends App{
  val readData : DataReader = new DataReader
  val tripList : List[Trips] = readData.getTripList
  val routeList : List[Routes] = readData.getRouteList
  val calendarList : List[Calendar] = readData.getCalendarList
  val routeLookup = new MapRouteLookup(routeList)
  val CalendarLookup = new MapCalendarLookup(calendarList)
  val enrichedTripRoute : List[TripRoute] = tripList.map(trip => TripRoute(trip, routeLookup.lookup(trip.route_id))).toList
  val enrichedTrip : List[Enriched] = enrichedTripRoute.map(tripRoute => Enriched(tripRoute,CalendarLookup.lookup(tripRoute.trips.service_id))).toList
  val writer = new DataWriter(enrichedTrip)
  writer.writeData

}
